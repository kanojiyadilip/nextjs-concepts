import React from 'react';
import Demo from './demo'

export default function about() {
    return(
        <>
        
        <h1>About Page</h1>
        
        <Demo/>
        </>
    )
}

//  const About = () =>
// export default About;